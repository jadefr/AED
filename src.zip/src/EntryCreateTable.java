
public class EntryCreateTable {
	String tableName;
	String[] headers;
	
	public EntryCreateTable(String tableName, String[] headers){
		this.tableName = tableName;
		this.headers = headers;
	}
	

}
